package org.example.mymission8;

import androidx.activity.result.ActivityResult;
import androidx.activity.result.ActivityResultCallback;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    TextView textView;
    EditText editText, editPassword;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        textView = findViewById(R.id.textView);
        editText = findViewById(R.id.editText);
        editPassword = findViewById(R.id.editPassword);

        Button button = findViewById(R.id.button);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (editText.getText().toString().isEmpty() || editPassword.getText().toString().isEmpty())
                    Toast.makeText(getApplicationContext(), "아이디 혹은 비밀번호가 입력되지 않았습니다!", Toast.LENGTH_LONG).show();
                else {
                    Intent intent = new Intent(getApplicationContext(), MenuActivity.class);
                    startActivity(intent);

                }
            }
        });

        Intent intent = getIntent();
        if (intent.getStringExtra("name") != null)
            Toast.makeText(getApplicationContext(), "이전화면 : " + intent.getStringExtra("name"), Toast.LENGTH_LONG).show();
    }
}